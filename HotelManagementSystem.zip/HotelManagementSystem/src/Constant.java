import java.util.Scanner;

public class Constant {
    public static String MAIN_URL = "jdbc:mysql://localhost:3306/";
    public static String DATABSE = "hotelmanagement";
    public static String USERNAME = "root";
    public static String PASSWORD = "";

}
